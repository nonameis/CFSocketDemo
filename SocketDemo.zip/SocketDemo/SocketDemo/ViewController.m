//
//  ViewController.m
//  SocketDemo
//
//  Created by ORION－Zues on 16/3/5.
//  Copyright © 2016年 ORION－Zues. All rights reserved.
//

#import "ViewController.h"

#import "CFClient.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *MsgField;
@property (weak, nonatomic) IBOutlet UILabel *MsgLabel;

@end

@implementation ViewController{
    
    CFClient *client;
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    client = [[CFClient alloc] initWithAddress:@"172.24.129.2" port:1234];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)sendButtonClicked:(id)sender {
    
    if (client && client.errorCode == NoError) {
        NSString *msg = [self.MsgField.text stringByTrimmingCharactersInSet:
                         [NSCharacterSet whitespaceCharacterSet]];
        if (msg.length > 0) {
            [self.MsgField resignFirstResponder];
            self.MsgLabel.text = [client sendMessage:msg];
        }
    }
    else {
        NSLog(@"Cannot send message!!!");
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
