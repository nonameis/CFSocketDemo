//
//  AppDelegate.h
//  SocketDemo
//
//  Created by ORION－Zues on 16/3/5.
//  Copyright © 2016年 ORION－Zues. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

